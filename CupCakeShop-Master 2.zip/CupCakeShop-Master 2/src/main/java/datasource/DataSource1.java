package datasource;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

public class DataSource1
{
    private MysqlDataSource dataSource = new MysqlDataSource();
    
    public DataSource1()
    {
        dataSource.setServerName("159.65.117.47");
        dataSource.setPort(3306); // 3306
        dataSource.setDatabaseName("CupCake");
        dataSource.setUser("mohammad");
        dataSource.setPassword("haririboy");
    }
    
    public MysqlDataSource getDataSource()
    {
        return dataSource;
    }
}
